
//上线打开
//console.log = function(){}
//const appRequest = false;
const appRequest = true;
//测试
const BASE_URL_CONFIG = 'http://47.114.136.117:8081/';
const BASE_URL_API = 'http://47.114.136.117:8086/';
//本地
//const BASE_URL_CONFIG = 'http://172.1.1.77:8081/';
//const BASE_URL_API = 'http://172.1.1.77:8086/';

//const AES_KEY = '14kd35r7z8d1er53';
//const AES_IV = '5e8y6w45ju8w9jq8';
//const DES_IV = 'v3j!7X@-';

const AES_KEY = '14kd35r7z8d1er53';
const AES_IV = '12sqdzhhj38d9zq7';
const DES_IV = 'zsd29X!%';
