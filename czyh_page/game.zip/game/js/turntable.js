var token;
var Data;
var rotate = 22.5;
if(GetQueryString('token')) {
	token = GetQueryString('token');
	window.localStorage.setItem('token', token);
}
http(URL.config, {
	attribute: 'head'
}).then(e => {
	URL_HEAD = e;
	window.localStorage.setItem('URL_HEAD', e);
	getData();
})
$(function() {
	//拼单抢购
	status('1');

});

function getData() {
	http(URL.turntable, {
		token: window.localStorage.getItem('token'),
	}).then(e => {
		Data = e;
		setTurnTable();
		setNameList();
		setassortedBlindBox();
	})
}
function setassortedBlindBox(){
	for (var i = 0; i < Data.assortedBlindBox.length; i++) {
		$('.prizeCont1').append(`<div class="item">
						<img src="../img/bg1.png" alt="" />
						<div class="msg">
							<div class="title">故宫猫祥瑞系列盲盒故宫猫故宫猫祥瑞故祥瑞系列盲盒故宫祥瑞故宫猫祥</div>
							<div class="num">
								<div><span>${Data.assortedBlindBox[i].price}</span>积分</div>
								<img onclick='toSyndicate(${i})' src="../img/turn_btn.png" />
							</div>
						</div>
					</div>`)
	}
}
function setNameList() {
	for(var i = 0; i < Data.winList.length; i++) {
		var img = URL_HEAD + Data.winList[i].head;
		var time = formatDate(Data.winList[i].createTime ,'2')
		$('.carousel_li').append(`<li class="item">
							<div class="left">
								<img src="${img}" />
								<div>
									<div class="top">${Data.winList[i].nickName}</div>
									<div class="bottom">${time}</div>
								</div>
							</div>
							<div class="right">获得了<span>${Data.winList[i].goods}</span></div>
						</li>`)
	}
	if(Data.winList.length > 5) {
		//中奖名单轮播
		$('#FontScroll').FontScroll({
			time: 3000,
			num: 1
		});
	}
}

function setTurnTable() {
	for(var i = 0; i < Data.drawList.length; i++) {
		var img = URL_HEAD + Data.drawList[i].img;
		//		console.log(rotate)
		$('.table').append(`<div class="item" style="transform: rotate(${rotate}deg);transform-origin: bottom;height: 1.65rem;width: .7rem;display: flex;position: absolute;align-items: center;flex-direction: column;">
						<img style="margin-top: .35rem;width: .5rem;height: .4rem;display: block;" src="${img}" />
						<div style="font-size: .1rem;color: #E13738;">${Data.drawList[i].name}</div>
					</div>`)
		rotate += 45;
		//		Data.drawList[i]
	}
}

function start() {
	$('.table').rotate({
		angle: 0,
		animateTo: 770,
		duration: 1000,
		callback: function() {
			//				alert('s')
		}
	});
}

function status(i) {
	$('.statu1').attr('src', '../img/turn_bg11.png');
	$('.statu2').attr('src', '../img/turn_bg10.png');
	$('.prizeCont').hide()
	if(i == 1) {
		$('.statu1').attr('src', '../img/turn_bg11_s.png')
		$('.prizeCont1').show()
	} else if(i == 2) {
		$('.statu2').attr('src', '../img/turn_bg10_s.png')
		$('.prizeCont2').show()
	}
}